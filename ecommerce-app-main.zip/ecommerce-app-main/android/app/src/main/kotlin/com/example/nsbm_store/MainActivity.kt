package com.example.nsbm_store

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
