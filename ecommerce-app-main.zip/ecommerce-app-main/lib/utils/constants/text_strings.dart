class NTexts {
// Here goes the general text on the system
}
