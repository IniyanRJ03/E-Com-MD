class NApiConstants {
  /// Here goes the API keys Stings
}