# Important Commands

## Create Splash Screens

```
flutter pub run flutter_native_splash:create --path=splash.yaml
```

## Remove Splash Screen

```
flutter pub run flutter_native_splash:remove --path=splash.yaml
```
